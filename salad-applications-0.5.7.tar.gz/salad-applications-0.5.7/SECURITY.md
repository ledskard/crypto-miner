# Security Policy

## Supported Versions

We only support the latest version of the Salad desktop and web applications. The desktop application will attempt to automatically update when a new version is published. The web application will automatically update every time the desktop application is launched.

## Reporting a Vulnerability

Please report security vulnerabilities to dev@salad.com.
