export enum ErrorAction {
  Ignore = 'ignore',
  Stop = 'stop',
  Restart = 'restart',
}
