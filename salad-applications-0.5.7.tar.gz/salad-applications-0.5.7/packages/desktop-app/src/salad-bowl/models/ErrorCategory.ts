export enum ErrorCategory {
  Unknown = 'unknown',
  Driver = 'driver',
  AntiVirus = 'antiVirus',
  Network = 'network',
  Silent = 'silent',
}
