export interface Profile {
  id: string
  username: string
  email: string
}
