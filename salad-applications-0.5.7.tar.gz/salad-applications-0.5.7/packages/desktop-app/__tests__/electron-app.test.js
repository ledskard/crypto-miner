"use strict";

const electronApp = require("..");

describe("desktop-app", () => {
  it("needs tests");
});
