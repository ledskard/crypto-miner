import { addons } from '@storybook/addons'

addons.setConfig({})
