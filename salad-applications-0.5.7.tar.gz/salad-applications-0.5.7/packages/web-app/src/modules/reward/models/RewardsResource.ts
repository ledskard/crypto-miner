import { RewardResource } from './RewardResource'

export interface RewardsResource {
  rewards?: RewardResource[]
}
