export enum MiningStatus {
  Installing = 'installing',
  Initializing = 'prepping',
  Running = 'chopping',
  Stopped = 'stopped',
}
