export interface MinerWorkload {
  name?: string
  version?: string
  algorithm?: string
}
