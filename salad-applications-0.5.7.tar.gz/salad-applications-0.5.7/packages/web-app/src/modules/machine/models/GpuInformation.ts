export interface GpuInformation {
  model: string
  vram: number
  driverVersion?: string
  compatible: boolean
}
