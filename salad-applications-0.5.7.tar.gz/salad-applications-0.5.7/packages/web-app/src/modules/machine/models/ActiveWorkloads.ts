export interface ActiveWorkloadProps {
  algorithm?: string
  name?: string
  version?: string
}

export type ActiveWorkloads = ActiveWorkloadProps[]
