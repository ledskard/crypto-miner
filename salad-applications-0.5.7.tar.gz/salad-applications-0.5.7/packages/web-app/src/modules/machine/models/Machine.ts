export interface Machine {
  id: string
  name: string
  minerId: string
}
