interface DesktopSettingPanel {
  panel: React.ReactNode
  isAdvanced: boolean
}

export type DesktopSettingPanels = DesktopSettingPanel[]
