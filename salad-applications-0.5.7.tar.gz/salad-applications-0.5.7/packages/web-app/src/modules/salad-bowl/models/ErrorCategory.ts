export enum ErrorCategory {
  Unknown = 'unknown',
  Driver = 'driver',
  AntiVirus = 'antiVirus',
  Firewall = 'firewall',
  Network = 'network',
  Silent = 'silent',
}
