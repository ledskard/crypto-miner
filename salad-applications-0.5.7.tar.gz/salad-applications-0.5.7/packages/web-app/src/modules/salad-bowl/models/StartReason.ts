export enum StartReason {
  Manual = 'manual',
  Automatic = 'automatic',
  Refresh = 'refresh',
}
