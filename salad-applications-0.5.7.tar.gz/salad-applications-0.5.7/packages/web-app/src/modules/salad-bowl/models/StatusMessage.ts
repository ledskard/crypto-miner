import { PluginStatus } from './PluginStatus'

export interface StatusMessage {
  name: string
  status: PluginStatus
}
