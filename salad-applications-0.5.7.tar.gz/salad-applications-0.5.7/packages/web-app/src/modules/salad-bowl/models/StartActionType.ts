export enum StartActionType {
  Automatic = 'Automatic',
  Override = 'Override',
  StartButton = 'Start Button',
  StopPrepping = 'Stop Prepping',
  SwitchMiner = 'Switch Miner',
}
