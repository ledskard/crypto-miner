export enum StopReason {
  Manual = 'manual',
  Automatic = 'automatic',
  Fallthrough = 'fallthrough',
  Logout = 'logout',
}
