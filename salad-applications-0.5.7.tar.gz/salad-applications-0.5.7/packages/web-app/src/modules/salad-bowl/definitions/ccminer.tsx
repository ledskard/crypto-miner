const baseUrl = 'https://github.com/SaladTechnologies/plugin-downloads/releases/download'

export const downloads = [
  {
    version: '2.3.1',
    windowsUrl: baseUrl + '/ccminer-2.31/ccminer-2-3-1-windows.zip',
  },
]
