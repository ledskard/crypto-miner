
export interface BonusEarningRate {
  bonusId?: string;
  earnedAmount?: number;
  earnedAmountLimit?: number;
  multiplier?: number;
}
