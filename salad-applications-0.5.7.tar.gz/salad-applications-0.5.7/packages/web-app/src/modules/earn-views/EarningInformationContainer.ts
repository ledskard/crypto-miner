import { connect } from '../../connect'
import { EarningInformationPage } from './pages/EarningInformationPage'

const mapStoreToProps = (): any => ({})

export const EarningInformationContainer = connect(mapStoreToProps, EarningInformationPage)
