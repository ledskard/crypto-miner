import { connect } from '../../connect'
import { RewardFilterList } from './components/RewardFilterList'

const mapStoreToProps = () => ({})

export const RewardFilterContainer = connect(mapStoreToProps, RewardFilterList)
