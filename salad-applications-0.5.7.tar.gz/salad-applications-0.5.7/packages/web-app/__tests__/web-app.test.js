'use strict';

const webApp = require('..');

describe('web-app', () => {
    it('needs tests');
});
